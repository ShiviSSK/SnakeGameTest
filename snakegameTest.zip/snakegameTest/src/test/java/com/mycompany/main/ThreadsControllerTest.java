/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.main;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

/**
 *
 * @author skshi
 */
public class ThreadsControllerTest {
	
	private ThreadsController threadController;

    
    public ThreadsControllerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Tests of class ThreadsController.
     */
    
    @Test
    @DisplayName("Check for Snake biting itself")
    public void testCheckCollisionSnakeDoesNotBiteItself() {
    	
    	//Creates the instance of keyboard listener and window class
        var window = new Window();
        Tuple headPosition = new Tuple(10, 10); // initial snake position
        var threadsController = new ThreadsController(headPosition); // Initialize ThreadsController
        
        //Adds positions (tuple) taken by the snake
        threadsController.positions.add(new Tuple(10, 11));
        threadsController.positions.add(new Tuple(10, 12));
        threadsController.positions.add(new Tuple(10, 13));
        
        //Call for the function to test
        threadsController.checkCollision();
        
        //Checks that the game has not stopped since the snake doesn't bite itself
        assertFalse(threadsController.gameStopped);

    }
    
    
    @Test
    @DisplayName("Check for Snake Eating Food")
    public void testSnakeEatingFood() {
    	
    	//Creates the instance of keyboard listener and window class
    	var window = new Window();
        Tuple initialSnakePosition = new Tuple(10, 10); // initial position
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);
        
        //Stores the size of the snake in a variable
        int firstSize = threadsController.sizeSnake;

        
        Tuple snakeHeadPosition = new Tuple(10, 11); 
        Tuple foodPosition = new Tuple(11, 10); // snake head position near food
        threadsController.positions.add(snakeHeadPosition); //adds the head position to the list
        threadsController.foodPosition = foodPosition; // food position to the same as snake head

        //Call for the function to test
        threadsController.checkCollision();

        //Checks that the snake size has increased by 1 since food has been eaten
        assertEquals(firstSize+1, threadsController.sizeSnake);
        
}
    
    
    @Test
    @DisplayName("Check for Snake has not eaten food")
    public void testSnakeNotEatingFood() {
    	
    	//Creates the instance of keyboard listener and window class
    	var window = new Window();
        Tuple initialSnakePosition = new Tuple(10, 10); 
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);
        
        //Stores the size of the snake in a variable
        int firstSize = threadsController.sizeSnake;

        
        Tuple snakeHeadPosition = new Tuple(10, 11); 
        Tuple foodPosition = new Tuple(11, 12);  // snake head position different from food
        threadsController.positions.add(snakeHeadPosition);
        threadsController.foodPosition = foodPosition; 

        //Call for the function to test
        threadsController.checkCollision();

        //Checks that the snake size has not increased by 1 since food has not been eaten
        assertNotEquals(firstSize+1, threadsController.sizeSnake);
        
}

    @Test
    @DisplayName("Food position value generated that is not occupied by snake")
    public void testGetValAleaNotInSnake() {
    	
    	//Creates the instance of threads controller and window class
    	var window = new Window();
    	Tuple initialSnakePosition = new Tuple(10, 10);
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);

        //Stores the list of positions occupied by the snake
        threadsController.positions.add(new Tuple(10, 11));
        threadsController.positions.add(new Tuple(10, 12));
        threadsController.positions.add(new Tuple(11, 12));
        

        
        //call the function and stores the result in variable
        Tuple randomTuple = threadsController.getValAleaNotInSnake();
        threadsController.positions.add(randomTuple);// add it to the list
        randomTuple = threadsController.getValAleaNotInSnake();
        

        // checks that the generated random Tuple is not in the positions array list
        assertFalse(threadsController.positions.contains(randomTuple));
        
    }
    
    
    @Test
    @DisplayName("Food position value generated that is not occupied by snake (for loop)")
    public void testGetValAleaNotInSnakeIfRandomGeneratedSame() {
    	
    	//Creates the instance of threads controller and window class
    	var window = new Window();
    	Tuple initialSnakePosition = new Tuple(10, 10);
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);

        //Stores the list of positions occupied by the snake
        //ArrayList<Tuple> positions = new ArrayList<>();
        for( int i = 0; i < 20; i++)
        	for(int j = 0; i < 20; i++)
        		threadsController.positions.add(new Tuple(i,j));
        
        //call the function and stores the result in variable
        Tuple randomTuple = threadsController.getValAleaNotInSnake();
        threadsController.positions.add(randomTuple);// add it to the list
        randomTuple = threadsController.getValAleaNotInSnake();
        

        // checks that the generated random Tuple is not in the positions array list
        assertFalse(threadsController.positions.contains(randomTuple));
        
    }
    
    
    @Test
    @DisplayName("Head of Snake moved down")
    //Tests that the head moves in the down direction and that position is added to the list
    public void testInterneMoveDown() {
    	
    	//Creates the instance of threads controller and window class
    	var window = new Window();
        Tuple initialSnakePosition = new Tuple(10,10); 
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);
        threadsController.positions.clear();
        
        threadsController.moveInterne(4); //move down
   
        assertEquals(10, threadsController.headSnakePos.x);
        assertEquals(11, threadsController.headSnakePos.y);
       
    }
    
    @Test
    @DisplayName("Head of Snake moved Top")
    public void testInterneMoveTop() {
    	var window = new Window();
        
        Tuple initialSnakePosition = new Tuple(10,10); 
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);
        threadsController.positions.clear();
        threadsController.moveInterne(3);
   
        assertEquals(10, threadsController.headSnakePos.x);
        assertEquals(9, threadsController.headSnakePos.y);
       
    }
    
    @Test
    @DisplayName("Head of Snake moved Top at the edge of grid")
    //Tests that when snake is at the upper edge of grid and is directed to move up, then it starts/comes again from the bottom of grid (game logic)
    public void testInterneMoveTopIfSnakeAtEdge() {
    	var window = new Window();
        // Create a ThreadsController instance
        Tuple initialSnakePosition = new Tuple(0,0); // Example initial position
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);
        threadsController.positions.clear();
        threadsController.moveInterne(3);
   
        assertEquals(0, threadsController.headSnakePos.x);
        assertEquals(19, threadsController.headSnakePos.y);
       
    }
    
    @Test
    public void testInterneMoveLeft() {
    	var window = new Window();
        
        Tuple initialSnakePosition = new Tuple(10,10); 
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);
        threadsController.positions.clear();
        threadsController.moveInterne(2);
   
        assertEquals(9, threadsController.headSnakePos.x);
        assertEquals(10, threadsController.headSnakePos.y);
       
    }
    
    @Test
    public void testInterneMoveLeftIfSnakeAtEdge() {
    	var window = new Window();
        
        Tuple initialSnakePosition = new Tuple(0,0); 
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);
        threadsController.positions.clear();
        threadsController.moveInterne(2);
   
        assertEquals(19, threadsController.headSnakePos.x);
        assertEquals(0, threadsController.headSnakePos.y);
       
    }
    
    @Test
    public void testInterneRight() {
    	var window = new Window();
        
        Tuple initialSnakePosition = new Tuple(10,10); 
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);
        threadsController.positions.clear();
        threadsController.moveInterne(1);
   
        assertEquals(11, threadsController.headSnakePos.x);
        assertEquals(10, threadsController.headSnakePos.y);
       
    }
    @Test
    public void testInterneNoMovement() {
    	var window = new Window();
        
        Tuple initialSnakePosition = new Tuple(10,10); 
        ThreadsController threadsController = new ThreadsController(initialSnakePosition);
        threadsController.positions.clear();
        threadsController.moveInterne(0);
   
        assertEquals(10, threadsController.headSnakePos.x);
        assertEquals(10, threadsController.headSnakePos.y);
       
    }

    /* Below tests are just given 
     * for additional purposes for other class coverage 
     */
    
    @Test
    //Tests the tuple getter and setter not covered
    public void testGetXfAndYf() {
    	var tuple = new Tuple(10, 20);
        // Test the getXf and getYf methods
        assertEquals(0, tuple.getXf()); // xf should be initialized to 0
        assertEquals(0, tuple.getYf()); // yf should be initialized to 0
    }
    
    @Test
    public void testMainMethod() {
        // Attempts to run the main method and check for any exceptions
            Main.main(new String[] {});
        
    }
    
}

