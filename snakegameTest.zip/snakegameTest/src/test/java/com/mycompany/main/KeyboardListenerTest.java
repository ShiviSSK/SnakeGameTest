/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.main;

import java.awt.event.KeyEvent; //for simulating the key events
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author skshi
 */
public class KeyboardListenerTest {
    
    
    public KeyboardListenerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
      
    }
    
    @AfterEach
    public void tearDown() {
    }

    
    /**
     * Test of keyPressed method, of class KeyboardListener.
     */
    
    @Test
    @DisplayName("Key Pressed Right")
    //Tests that right arrow key pressed directs the snake to the right
    public void testKeyPressedRightGoesRight() {
    	//Creates the instance of keyboard listener and window class
        var KeyboardListener = new KeyboardListener();
        var window = new Window();
        
        //Key Event that simulates the right key press || the fifth parameter is the keycode (which in this case is 39)
        KeyEvent rightArrowKeyEvent = new KeyEvent(window, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, 39, KeyEvent.CHAR_UNDEFINED);
        KeyboardListener.keyPressed(rightArrowKeyEvent); // passing the event to the function for response
        
        // Checks if the expected direction (1;right) matches the output direction (direction of the snake)
        assertEquals(1,ThreadsController.directionSnake);
        
        
    }
    
    @Test
    @DisplayName("Key Pressed Right when snake direction is left")
    //Tests that right arrow key pressed does not direct the snake to the right if the snake direction is left (game logic)
    public void testKeyPressedRightDoesntGoRightIfSnakeDirectionLeft() {
    	//Creates the instance of keyboard listener and window class
        var KeyboardListener = new KeyboardListener();
        var window = new Window();
        
        //Sets the direction of snake to left;2
        ThreadsController.directionSnake = 2;
        
        KeyEvent rightArrowKeyEvent = new KeyEvent(window, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, 39, KeyEvent.CHAR_UNDEFINED);
        KeyboardListener.keyPressed(rightArrowKeyEvent);
        
        //Checks that the snake has not changed the direction 
        // i.e checks that expected direction (1;right) does not match the output direction (direction of the snake)
        assertNotEquals(1, ThreadsController.directionSnake);
    }
    
    @Test
    @DisplayName("Key Pressed Up")
    //Tests that up arrow key pressed directs the snake direction up
    public void testKeyPressedUpGoesUp() {
    	//Creates the instance of keyboard listener and window class
        var KeyboardListener = new KeyboardListener();
        var window = new Window();
        
        //Key Event that simulates the up key press || the fifth parameter is the keycode (which in this case is 38)
        KeyEvent upArrowKeyEvent = new KeyEvent(window, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, 38, KeyEvent.CHAR_UNDEFINED);
        KeyboardListener.keyPressed(upArrowKeyEvent);
        
        //Checks if the expected direction (3;up) matches the output direction (direction of the snake)
        assertEquals(3,ThreadsController.directionSnake);
                  
    }
        
    @Test
    @DisplayName("Key Pressed Up when snake direction is down")
    public void testKeyPressedUpDoesntGoUpIfSnakeDirectionDown() {
    	//Creates the instance of keyboard listener and window class
        var KeyboardListener = new KeyboardListener();
        var window = new Window();
        
        //Sets the direction of snake to down;4
        ThreadsController.directionSnake = 4;
        
        //Key Event that simulates the up key press || the fifth parameter is the keycode (which in this case is 38)
        KeyEvent upArrowKeyEvent = new KeyEvent(window, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, 38, KeyEvent.CHAR_UNDEFINED);
        KeyboardListener.keyPressed(upArrowKeyEvent);
        
        //Checks that the snake has not changed the direction 
        // i.e checks that expected direction (3;Up) does not match the output direction (direction of the snake)
        assertNotEquals(3, ThreadsController.directionSnake);
    
    
    }
    
    @Test
    @DisplayName("Key Pressed Left")
    //Tests that up arrow key pressed directs the snake direction to the left
    public void testKeyPressedLeftGoesLeft() {
    	//Creates the instance of keyboard listener and window class
        var KeyboardListener = new KeyboardListener();
        var window = new Window();
        
        
        ThreadsController.directionSnake = 4; //Since the initial direction of snake is right, the direction is changed to down for verification
        
        //Key Event that simulates the left key press || the fifth parameter is the keycode (which in this case is 37)
        KeyEvent leftArrowKeyEvent = new KeyEvent(window, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, 37, KeyEvent.CHAR_UNDEFINED);
        KeyboardListener.keyPressed(leftArrowKeyEvent);
        
        // Checks if the expected direction (2;left) matches the output direction (direction of the snake)
        assertEquals(2,ThreadsController.directionSnake);
                 
    }
    
    @Test
    @DisplayName("Key Pressed Left when snake direction is right")
    public void testKeyPressedLeftDoesntGoLeftIfSnakeDirectionRight() {
    	//Creates the instance of keyboard listener and window class
        var KeyboardListener = new KeyboardListener();
        var window = new Window();
        
        //Sets the direction of snake to right;1
        ThreadsController.directionSnake = 1;
        
        //Key Event that simulates the left key press || the fifth parameter is the keycode (which in this case is 37)
        KeyEvent leftArrowKeyEvent = new KeyEvent(window, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, 37, KeyEvent.CHAR_UNDEFINED);
        KeyboardListener.keyPressed(leftArrowKeyEvent);
        
        //Checks that the snake has not changed the direction 
        // i.e checks that expected direction (2;left) does not match the output direction (direction of the snake)
        assertNotEquals(2, ThreadsController.directionSnake);
    }
    
    @Test
    @DisplayName("Key Pressed Down")
    //Tests that down arrow key pressed directs the snake direction down
    public void testKeyPressedDownGoesDown() {
    	//Creates the instance of keyboard listener and window class
        var KeyboardListener = new KeyboardListener();
        var window = new Window();
        
        //Key Event that simulates the down key press || the fifth parameter is the keycode (which in this case is 40)
        KeyEvent downArrowKeyEvent = new KeyEvent(window, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, 40, KeyEvent.CHAR_UNDEFINED);
        KeyboardListener.keyPressed(downArrowKeyEvent);
        
        // Checks if the expected direction (4;down) matches the output direction (direction of the snake)
        assertEquals(4,ThreadsController.directionSnake);
                 
  }
    
    @Test
    @DisplayName("Key Pressed Down when snake direction is up")
    public void testKeyPressedDownDoesntGoDownIfSnakeDirectionUp() {
    	//Creates the instance of keyboard listener and window class
        var KeyboardListener = new KeyboardListener();
        var window = new Window();
        
        //Sets the direction of snake to up;3
        ThreadsController.directionSnake = 3;
        
        //Key Event that simulates the down key press || the fifth parameter is the keycode (which in this case is 40)
        KeyEvent downArrowKeyEvent = new KeyEvent(window, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, 40, KeyEvent.CHAR_UNDEFINED);
        KeyboardListener.keyPressed(downArrowKeyEvent);
        
        //Checks that the snake has not changed the direction 
        // i.e checks that expected direction (4;down) does not match the output direction (direction of the snake)
        assertNotEquals(4, ThreadsController.directionSnake);
    }
   
    @Test
    @DisplayName("Any Other key pressed apart from arrow keys")
    //Tests that if any other key pressed, apart from the arrow keys, then there is no change in direction
    public void testKeyPressedOther(){
    	//Creates the instance of keyboard listener and window class
        var KeyboardListener = new KeyboardListener();
        var window = new Window();
        
        //sets the initial direction to right; 1
        ThreadsController.directionSnake = 1;
        
        //Key Event that simulates the any other key press || the fifth parameter is the keycode (which in this case was a random 45)
        KeyEvent otherKeyEvent = new KeyEvent(window, KeyEvent.KEY_PRESSED, System.currentTimeMillis(), 0, 45, KeyEvent.CHAR_UNDEFINED);
        KeyboardListener.keyPressed(otherKeyEvent);
        
        //checks that there is no change in the initial direction because of any other keys pressed
        assertEquals(1,ThreadsController.directionSnake);
    }
         

}
